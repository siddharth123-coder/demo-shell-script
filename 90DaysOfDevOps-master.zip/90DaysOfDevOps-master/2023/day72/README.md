Day 72 - Grafana🔥

Hello Learners , you guys are doing really a good job. You will not be there 24\*7 to monitor your resources. So, Today let’s monitor the resources in a smart way with - Grafana 🎉

## Task 1:

> What is Grafana? What are the features of Grafana?
> Why Grafana?
> What type of monitoring can be done via Grafana?
> What databases work with Grafana?
> What are metrics and visualizations in Grafana?
> What is the difference between Grafana vs Prometheus?

---

[← Previous Day](../day71/README.md) | [Next Day →](../day73/README.md)
