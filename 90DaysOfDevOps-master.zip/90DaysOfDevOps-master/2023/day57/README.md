# Day 57: Ansible Hands-on with video

Ansible is fun, you saw in last few days how easy it is.

Let's make it fun now, by using a video explanation for Ansible.

# Task-01

- Write a Blog explanation for the [ansible video](https://youtu.be/SGB7EdiP39E)

happy Learning :)

[← Previous Day](../day56/README.md) | [Next Day →](../day58/README.md)
