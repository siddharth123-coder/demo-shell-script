# Day 49 - INTERVIEW QUESTIONS ON AWS

Hey people, we have listened to your suggestions and we are looking forward to get more!
As you people have asked to put more interview based questions as part of Daily Task, So here it it :)

## INTERVIEW QUESTIONS:

- Name 5 aws services you have used and what's the use cases?
- What are the tools used to send logs to the cloud environment?
- What are IAM Roles? How do you create /manage them?
- How to upgrade or downgrade a system with zero downtime?
- What is infrastructure as code and how do you use it?
- What is a load balancer? Give scenarios of each kind of balancer based on your experience.
- What is CloudFormation and why is it used for?
- Difference between AWS CloudFormation and AWS Elastic Beanstalk?
- What are the kinds of security attacks that can occur on the cloud? And how can we minimize them?
- Can we recover the EC2 instance when we have lost the key?
- What is a gateway?
- What is the difference between the Amazon Rds, Dynamodb, and Redshift?
- Do you prefer to host a website on S3? What's the reason if your answer is either yes or no?

Let's share your answer on LinkedIn in best possible way thinking you are in a interview table.
Happy Learning !! :)

[← Previous Day](../day48/README.md) | [Next Day →](../day50/README.md)
